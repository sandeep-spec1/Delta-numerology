# Delta Numerology & Astrology Tool
Simple React app for calculating life path numbers.