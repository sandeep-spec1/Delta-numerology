
import React, { useState } from 'react';
import './App.css';

const calculateLifePath = (dob) => {
  const digits = dob.replace(/[^0-9]/g, '').split('').map(Number);
  let sum = digits.reduce((a, b) => a + b, 0);
  while (sum > 9 && sum !== 11 && sum !== 22 && sum !== 33) {
    sum = sum.toString().split('').reduce((a, b) => a + parseInt(b), 0);
  }
  return sum;
};

const App = () => {
  const [name, setName] = useState('');
  const [dob, setDob] = useState('');
  const [result, setResult] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    const lifePath = calculateLifePath(dob);
    setResult(`Hello ${name}, your Life Path Number is ${lifePath}. This number gives insight into your life’s purpose, strengths, and challenges.`);
  };

  return (
    <div className="App">
      <h1>Delta Astrology & Numerology</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Enter your name" value={name} onChange={e => setName(e.target.value)} required />
        <input type="date" value={dob} onChange={e => setDob(e.target.value)} required />
        <button type="submit">Get Insights</button>
      </form>
      {result && <div className="result">{result}</div>}
    </div>
  );
};

export default App;
